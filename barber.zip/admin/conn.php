<?php

    // $conn = mysqli_connect('localhost', 'root', 'AreguaPass234', 'areguap_crisda');
    $conn = mysqli_connect('localhost', 'root', '', 'barber');

?>